# SmarterChat - Especificação UI/UX

## 1. Princípios de Design

### 1.1 Design Futurista e Clean

**Características principais:**
- **Minimalismo inteligente**: Interfaces limpas sem elementos desnecessários
- **Glassmorphism sutil**: Efeitos de vidro fosco em cards e modais
- **Bordas suaves**: Border-radius generosos (12-24px)
- **Espaçamento respirável**: Uso generoso de whitespace
- **Tipografia moderna**: Fontes sans-serif (Inter, Outfit, Space Grotesk)
- **Microinterações**: Animações suaves e feedback visual

### 1.2 Sistema de Cores

**Modo Escuro (Padrão):**
```css
--background-primary: #0A0E1A;
--background-secondary: #141824;
--background-tertiary: #1E2330;
--surface: rgba(255, 255, 255, 0.05);
--surface-hover: rgba(255, 255, 255, 0.08);

--text-primary: #FFFFFF;
--text-secondary: #A0AEC0;
--text-tertiary: #718096;

--accent-primary: #6366F1; /* Indigo */
--accent-secondary: #8B5CF6; /* Purple */
--accent-gradient: linear-gradient(135deg, #6366F1 0%, #8B5CF6 100%);

--success: #10B981;
--warning: #F59E0B;
--error: #EF4444;
--info: #3B82F6;

--border: rgba(255, 255, 255, 0.1);
--shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.3);
```

**Modo Claro (Opcional):**
```css
--background-primary: #FFFFFF;
--background-secondary: #F9FAFB;
--background-tertiary: #F3F4F6;
--surface: rgba(0, 0, 0, 0.02);

--text-primary: #1F2937;
--text-secondary: #6B7280;
--text-tertiary: #9CA3AF;

/* Accent colors permanecem os mesmos */
```

### 1.3 Tipografia

```css
/* Headings */
--font-display: 'Space Grotesk', sans-serif;
--font-body: 'Inter', sans-serif;

h1 { font-size: 2.5rem; font-weight: 700; line-height: 1.2; }
h2 { font-size: 2rem; font-weight: 600; line-height: 1.3; }
h3 { font-size: 1.5rem; font-weight: 600; line-height: 1.4; }
h4 { font-size: 1.25rem; font-weight: 500; line-height: 1.5; }

/* Body */
body { font-size: 1rem; line-height: 1.6; }
small { font-size: 0.875rem; }
```

### 1.4 Componentes Base

**Botões:**
```css
/* Primary Button */
.btn-primary {
  background: var(--accent-gradient);
  color: white;
  padding: 12px 24px;
  border-radius: 12px;
  font-weight: 500;
  transition: all 0.2s;
  box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
}

.btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 20px rgba(99, 102, 241, 0.4);
}

/* Ghost Button */
.btn-ghost {
  background: transparent;
  border: 1px solid var(--border);
  color: var(--text-primary);
  padding: 12px 24px;
  border-radius: 12px;
}
```

**Cards:**
```css
.card {
  background: var(--background-secondary);
  border: 1px solid var(--border);
  border-radius: 16px;
  padding: 24px;
  backdrop-filter: blur(10px);
  transition: all 0.3s;
}

.card:hover {
  border-color: var(--accent-primary);
  box-shadow: var(--shadow);
}
```

**Inputs:**
```css
.input {
  background: var(--background-tertiary);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 12px 16px;
  color: var(--text-primary);
  transition: all 0.2s;
}

.input:focus {
  border-color: var(--accent-primary);
  box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
}
```

## 2. Estrutura de Páginas

### 2.1 Layout Principal

```
┌─────────────────────────────────────────────────────────┐
│  Sidebar (240px)  │         Main Content                │
│                   │                                      │
│  [Logo]           │  ┌─ Header ─────────────────────┐  │
│                   │  │  Page Title    [Actions]      │  │
│  Navigation       │  └───────────────────────────────┘  │
│  • Dashboard      │                                      │
│  • Conversas      │  ┌─ Content Area ───────────────┐  │
│  • Leads          │  │                               │  │
│  • Agentes        │  │                               │  │
│  • Canais         │  │                               │  │
│  • Webhooks       │  │                               │  │
│  • Analytics      │  │                               │  │
│                   │  │                               │  │
│  [User Profile]   │  └───────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
```

### 2.2 Sidebar Navigation

**Design:**
- Fundo: `--background-secondary`
- Largura: 240px (expansível para 64px quando colapsada)
- Ícones: Phosphor Icons ou Lucide Icons
- Indicador de página ativa: Barra vertical colorida + fundo destacado

**Componentes:**
```jsx
<Sidebar>
  <Logo />
  <NavSection title="Principal">
    <NavItem icon={<LayoutDashboard />} label="Dashboard" active />
    <NavItem icon={<MessageSquare />} label="Conversas" badge={5} />
    <NavItem icon={<Users />} label="Leads" />
  </NavSection>
  <NavSection title="Configuração">
    <NavItem icon={<Bot />} label="Agentes" />
    <NavItem icon={<Plug />} label="Canais" />
    <NavItem icon={<Webhook />} label="Webhooks" />
  </NavSection>
  <UserProfile />
</Sidebar>
```

## 3. Telas Principais

### 3.1 Dashboard

**Layout:**
```
┌─────────────────────────────────────────────────────────┐
│  Dashboard                              [Filtros: 30d ▼]│
├─────────────────────────────────────────────────────────┤
│                                                          │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐  │
│  │ 🔵 500   │ │ 🟢 200   │ │ 🟡 30    │ │ 📈 15%   │  │
│  │ Conversas│ │ Leads    │ │ Ativos   │ │ Conversão│  │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘  │
│                                                          │
│  ┌─ Conversas por Canal ──────────┐ ┌─ Leads ────────┐│
│  │                                 │ │                 ││
│  │  [Gráfico de linha temporal]   │ │ [Funil vendas] ││
│  │                                 │ │                 ││
│  └─────────────────────────────────┘ └─────────────────┘│
│                                                          │
│  ┌─ Performance dos Agentes ──────────────────────────┐ │
│  │                                                     │ │
│  │  Agente              Conversas  Tempo Resp  Score  │ │
│  │  🤖 Vendas              150      1.2s       4.5⭐  │ │
│  │  🤖 Suporte              80      2.1s       4.2⭐  │ │
│  │                                                     │ │
│  └─────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────┘
```

**Componentes:**
- **Stat Cards**: Cards com ícone, valor grande, label e trend
- **Charts**: Recharts com tema dark
- **Table**: Tabela responsiva com hover states

### 3.2 Conversas (Chat Interface)

**Layout de 3 Colunas:**
```
┌──────────────────────────────────────────────────────────┐
│ Lista (320px)  │  Chat (flex)      │  Detalhes (280px)  │
├────────────────┼───────────────────┼────────────────────┤
│ [Busca]        │ Maria Silva       │ 👤 Lead Info       │
│ [Filtros]      │ +55 11 98888-8888 │                    │
│                │ ─────────────────  │ Nome: Maria Silva  │
│ 🟢 Maria Silva │                    │ Email: maria@...   │
│   Oi, gostaria │ ┌─────────────┐   │ Temp: 🔥 HOT       │
│   de saber...  │ │ Olá!        │   │ Score: 85          │
│   14:30        │ │             │   │                    │
│                │ └─────────────┘   │ ─────────────────  │
│ 🔵 João Santos │      14:00        │ 📊 Contexto        │
│   Preciso de   │                    │                    │
│   ajuda com... │     ┌─────────┐   │ Interesse:         │
│   13:45        │     │ Temos 3 │   │ Plano Premium      │
│                │     │ planos  │   │                    │
│ ⚪ Ana Costa   │     └─────────┘   │ Empresa:           │
│   Obrigada!    │          14:01    │ Tech Corp          │
│   12:20        │                    │                    │
│                │ ┌─────────────┐   │ ─────────────────  │
│                │ │ Gostaria de │   │ 🎯 Ações           │
│                │ │ mais info   │   │                    │
│                │ └─────────────┘   │ [Assumir]          │
│                │      14:30        │ [Transferir]       │
│                │                    │ [Fechar]           │
│                │ ─────────────────  │                    │
│                │ [Digite...]  [📎] │                    │
└────────────────┴───────────────────┴────────────────────┘
```

**Características:**
- **Lista de conversas**: 
  - Status indicator (verde=ativo, azul=aguardando, cinza=fechado)
  - Preview da última mensagem
  - Timestamp relativo
  - Badge de mensagens não lidas
  - Filtros: Todas, Ativas, Aguardando, Minhas

- **Área de chat**:
  - Mensagens do cliente: alinhadas à esquerda, fundo cinza
  - Mensagens da IA: alinhadas à direita, fundo roxo/gradiente
  - Mensagens do consultor: alinhadas à direita, fundo azul
  - Indicador "Digitando..." com animação
  - Sugestões de resposta (quando consultor assume)

- **Painel de detalhes**:
  - Informações do lead
  - Contexto coletado
  - Ações rápidas
  - Histórico de atividades

### 3.3 Leads (CRM)

**Layout:**
```
┌─────────────────────────────────────────────────────────┐
│  Leads                    [+ Novo Lead]  [Filtros ▼]    │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐  │
│  │ 🔥 60    │ │ 🟡 80    │ │ 🔵 60    │ │ 💰 30    │  │
│  │ Quentes  │ │ Mornos   │ │ Frios    │ │ Convertid│  │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘  │
│                                                          │
│  [Buscar leads...]                    [Visualização: ⊞] │
│                                                          │
│  ┌─────────────────────────────────────────────────────┐│
│  │ Nome          Temp  Score  Origem    Consultor  Ações││
│  ├─────────────────────────────────────────────────────┤│
│  │ 🔥 Maria Silva  HOT   85   WhatsApp  João      [...]││
│  │    maria@empresa.com                                ││
│  │    Interesse: Plano Premium                         ││
│  │                                                      ││
│  │ 🟡 Pedro Santos WARM  65   Instagram Ana       [...]││
│  │    pedro@startup.com                                ││
│  │    Interesse: Plano Starter                         ││
│  └─────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────┘
```

**Visualizações:**
- **Lista**: Tabela expandível com detalhes
- **Kanban**: Colunas por temperatura ou status
- **Funil**: Visualização de pipeline de vendas

**Detalhes do Lead (Modal/Drawer):**
```
┌─────────────────────────────────────┐
│  Maria Silva                    [×] │
├─────────────────────────────────────┤
│                                     │
│  📧 maria@empresa.com               │
│  📱 +55 11 98888-8888               │
│  🏢 Tech Corp - CTO                 │
│                                     │
│  ┌─ Status ──────────────────────┐ │
│  │ 🔥 HOT  │  Score: 85  │  ⭐⭐⭐ │ │
│  └───────────────────────────────┘ │
│                                     │
│  ┌─ Interesse ───────────────────┐ │
│  │ Plano Premium                  │ │
│  │ Orçamento: R$ 10.000/mês       │ │
│  └───────────────────────────────┘ │
│                                     │
│  ┌─ Timeline ────────────────────┐ │
│  │ 📝 Nota adicionada - Hoje     │ │
│  │ 💬 Conversa iniciada - Ontem  │ │
│  │ 🎯 Lead criado - 2 dias atrás │ │
│  └───────────────────────────────┘ │
│                                     │
│  [+ Adicionar Nota]  [Editar]      │
└─────────────────────────────────────┘
```

### 3.4 Configuração de Agente

**Wizard Multi-Step:**

**Step 1: Informações Básicas**
```
┌─────────────────────────────────────────────────────────┐
│  Criar Agente                            [1/5] Básico   │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  ┌─ Avatar ──────────────────────────────────────────┐  │
│  │         [📷]                                       │  │
│  │    Clique para fazer upload                        │  │
│  └────────────────────────────────────────────────────┘  │
│                                                          │
│  Nome do Agente *                                        │
│  ┌────────────────────────────────────────────────────┐ │
│  │ Assistente de Vendas                               │ │
│  └────────────────────────────────────────────────────┘ │
│                                                          │
│  Descrição                                               │
│  ┌────────────────────────────────────────────────────┐ │
│  │ Agente especializado em qualificação de leads...  │ │
│  │                                                    │ │
│  └────────────────────────────────────────────────────┘ │
│                                                          │
│                              [Cancelar]  [Próximo →]    │
└─────────────────────────────────────────────────────────┘
```

**Step 2: Personalidade**
```
┌─────────────────────────────────────────────────────────┐
│  Criar Agente                       [2/5] Personalidade │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  Tom de Voz                                              │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐  │
│  │ Profiss. │ │ Amigável │ │ Casual   │ │ Formal   │  │
│  │    ✓     │ │          │ │          │ │          │  │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘  │
│                                                          │
│  Objetivo do Agente *                                    │
│  ┌────────────────────────────────────────────────────┐ │
│  │ Qualificar leads, coletar informações e agendar   │ │
│  │ reuniões com o time de vendas                     │ │
│  └────────────────────────────────────────────────────┘ │
│                                                          │
│  Personalidade                                           │
│  ┌────────────────────────────────────────────────────┐ │
│  │ Você é um assistente de vendas profissional e     │ │
│  │ amigável. Seu objetivo é entender as necessidades │ │
│  │ do cliente e oferecer soluções adequadas...       │ │
│  │                                                    │ │
│  └────────────────────────────────────────────────────┘ │
│                                                          │
│                              [← Voltar]  [Próximo →]    │
└─────────────────────────────────────────────────────────┘
```

**Step 3: Configuração de IA**
```
┌─────────────────────────────────────────────────────────┐
│  Criar Agente                      [3/5] Configuração IA│
├─────────────────────────────────────────────────────────┤
│                                                          │
│  OpenAI API Key * 🔒                                     │
│  ┌────────────────────────────────────────────────────┐ │
│  │ sk-••••••••••••••••••••••••••••••••••••••         │ │
│  └────────────────────────────────────────────────────┘ │
│  ℹ️ Sua chave será criptografada e armazenada com      │
│     segurança                                            │
│                                                          │
│  Modelo                                                  │
│  ┌────────────────────────────────────────────────────┐ │
│  │ GPT-4 Turbo                                     ▼  │ │
│  └────────────────────────────────────────────────────┘ │
│                                                          │
│  Temperatura: 0.7                                        │
│  ├────────●─────────────────────────────────────────┤   │
│  0 (Preciso)                           2 (Criativo)     │
│                                                          │
│  Máximo de Tokens: 1000                                  │
│  ├──────────────●──────────────────────────────────┤   │
│  100                                          4000       │
│                                                          │
│  System Message *                                        │
│  ┌────────────────────────────────────────────────────┐ │
│  │ Você é um assistente de vendas da empresa XYZ.   │ │
│  │ Sempre seja educado e profissional...            │ │
│  │                                                    │ │
│  └────────────────────────────────────────────────────┘ │
│                                                          │
│                              [← Voltar]  [Próximo →]    │
└─────────────────────────────────────────────────────────┘
```

**Step 4: Scripts e Regras**
```
┌─────────────────────────────────────────────────────────┐
│  Criar Agente                    [4/5] Scripts e Regras │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  Scripts Personalizados                  [+ Novo Script]│
│  ┌────────────────────────────────────────────────────┐ │
│  │ 📝 Validar Email                              [×]  │ │
│  │    Valida formato de email antes de salvar         │ │
│  │    [Editar]                                         │ │
│  └────────────────────────────────────────────────────┘ │
│                                                          │
│  Regras de Transferência para Humano                    │
│  ┌────────────────────────────────────────────────────┐ │
│  │ ☑ Palavras-chave detectadas                        │ │
│  │   "falar com humano", "atendente", "gerente"       │ │
│  │                                                     │ │
│  │ ☑ Sentimento muito negativo (< -0.5)               │ │
│  │                                                     │ │
│  │ ☑ Baixa confiança da IA (< 60%)                    │ │
│  │                                                     │ │
│  │ ☑ Loop de conversa detectado (3+ msgs similares)   │ │
│  └────────────────────────────────────────────────────┘ │
│                                                          │
│  Regras de Qualificação de Leads                        │
│  ┌────────────────────────────────────────────────────┐ │
│  │ Pergunta sobre preço:        +10 pontos            │ │
│  │ Interesse em demo:           +15 pontos            │ │
│  │ Urgência expressa:           +20 pontos            │ │
│  │ Orçamento mencionado:        +15 pontos            │ │
│  └────────────────────────────────────────────────────┘ │
│                                                          │
│                              [← Voltar]  [Próximo →]    │
└─────────────────────────────────────────────────────────┘
```

**Step 5: Webhooks**
```
┌─────────────────────────────────────────────────────────┐
│  Criar Agente                         [5/5] Webhooks    │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  Webhooks                                [+ Novo Webhook]│
│  ┌────────────────────────────────────────────────────┐ │
│  │ 🔗 Notificar CRM                              [×]  │ │
│  │    https://meucrm.com/webhook                      │ │
│  │    Eventos: lead.created, lead.qualified           │ │
│  │    Status: ✅ Ativo                                 │ │
│  │    [Testar] [Editar]                               │ │
│  └────────────────────────────────────────────────────┘ │
│                                                          │
│  ┌─ Novo Webhook ─────────────────────────────────────┐│
│  │                                                     ││
│  │ Nome                                                ││
│  │ ┌─────────────────────────────────────────────────┐││
│  │ │                                                 │││
│  │ └─────────────────────────────────────────────────┘││
│  │                                                     ││
│  │ URL                                                 ││
│  │ ┌─────────────────────────────────────────────────┐││
│  │ │ https://                                        │││
│  │ └─────────────────────────────────────────────────┘││
│  │                                                     ││
│  │ Eventos                                             ││
│  │ ☐ conversation.new    ☐ message.received           ││
│  │ ☑ lead.created        ☑ lead.qualified             ││
│  │ ☐ conversation.closed                               ││
│  │                                                     ││
│  │                        [Cancelar] [Adicionar]      ││
│  └─────────────────────────────────────────────────────┘│
│                                                          │
│                              [← Voltar]  [Criar Agente] │
└─────────────────────────────────────────────────────────┘
```

### 3.5 Analytics

**Layout:**
```
┌─────────────────────────────────────────────────────────┐
│  Analytics                    [Período: Últimos 30 dias ▼]│
├─────────────────────────────────────────────────────────┤
│                                                          │
│  ┌─ Conversas ──────────────────────────────────────┐   │
│  │                                                   │   │
│  │  [Gráfico de linha - Timeline de conversas]      │   │
│  │  Com separação: IA vs Humano                      │   │
│  │                                                   │   │
│  └───────────────────────────────────────────────────┘   │
│                                                          │
│  ┌─ Funil de Leads ──┐  ┌─ Canais ──────────────────┐  │
│  │                    │  │                            │  │
│  │  200 Novos         │  │  [Gráfico de pizza]       │  │
│  │   ↓                │  │  WhatsApp: 60%            │  │
│  │  120 Qualificados  │  │  Instagram: 40%           │  │
│  │   ↓                │  │                            │  │
│  │  30 Convertidos    │  └────────────────────────────┘  │
│  │                    │                                  │
│  └────────────────────┘  ┌─ Horários de Pico ────────┐  │
│                          │                            │  │
│  ┌─ Performance IA ───┐ │  [Heatmap de horários]     │  │
│  │                     │ │                            │  │
│  │ Tempo Resp: 1.2s   │ │                            │  │
│  │ Confiança: 92%     │ └────────────────────────────┘  │
│  │ Handoff: 10%       │                                  │
│  │                     │                                  │
│  └─────────────────────┘                                 │
└─────────────────────────────────────────────────────────┘
```

## 4. Componentes Especiais

### 4.1 Chat Bubble

```jsx
<MessageBubble
  type="ai" // ai, user, contact
  content="Olá! Como posso ajudar?"
  timestamp="14:30"
  status="read" // sent, delivered, read
  confidence={0.95} // apenas para IA
/>
```

**Estilos:**
- **Contact**: Fundo cinza escuro, alinhado à esquerda
- **AI**: Fundo gradiente roxo, alinhado à direita, ícone de robô
- **User**: Fundo azul, alinhado à direita, avatar do consultor

### 4.2 Lead Temperature Badge

```jsx
<TemperatureBadge temperature="hot" />
```

- **Hot**: 🔥 Vermelho com gradiente
- **Warm**: 🟡 Amarelo/Laranja
- **Cold**: 🔵 Azul

### 4.3 Typing Indicator

```jsx
<TypingIndicator user="Maria Silva" />
```

Animação de 3 pontos pulsando.

### 4.4 Sugestões de Resposta (AI Suggestions)

```jsx
<ResponseSuggestions
  suggestions={[
    "Claro! Posso te explicar nossos planos.",
    "Vou transferir você para um especialista.",
    "Que ótimo! Vamos agendar uma demonstração?"
  ]}
  onSelect={(suggestion) => {}}
/>
```

Aparecem acima do input quando consultor assume conversa.

### 4.5 Empty States

**Ilustrações minimalistas:**
- Sem conversas: Ilustração de chat vazio
- Sem leads: Ilustração de funil vazio
- Sem agentes: Ilustração de robô
- Erro: Ilustração de erro amigável

## 5. Microinterações

### 5.1 Animações

**Entrada de elementos:**
```css
@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
```

**Loading states:**
- Skeleton screens para carregamento
- Spinner com gradiente animado
- Progress bars para uploads

**Hover effects:**
- Cards: Elevação + borda colorida
- Botões: Elevação + brilho
- Links: Underline animado

### 5.2 Feedback Visual

**Sucesso:**
- Toast notification verde
- Checkmark animado
- Confetti (para ações importantes)

**Erro:**
- Toast notification vermelho
- Shake animation
- Mensagem clara do erro

**Loading:**
- Skeleton screens
- Shimmer effect
- Progress indicators

## 6. Responsividade

### 6.1 Breakpoints

```css
/* Mobile */
@media (max-width: 640px) { }

/* Tablet */
@media (min-width: 641px) and (max-width: 1024px) { }

/* Desktop */
@media (min-width: 1025px) { }
```

### 6.2 Adaptações Mobile

**Sidebar:**
- Colapsa em drawer/menu hambúrguer
- Navegação inferior (bottom navigation)

**Chat:**
- Lista de conversas em tela cheia
- Chat em tela cheia ao selecionar
- Detalhes em drawer deslizante

**Tabelas:**
- Cards empilhados
- Scroll horizontal
- Ações em menu dropdown

## 7. Acessibilidade

### 7.1 Requisitos WCAG 2.1 AA

- **Contraste**: Mínimo 4.5:1 para texto normal
- **Foco**: Indicadores visíveis de foco
- **Navegação por teclado**: Todos os elementos interativos
- **ARIA labels**: Para ícones e elementos sem texto
- **Semântica HTML**: Uso correto de tags

### 7.2 Atalhos de Teclado

```
Ctrl/Cmd + K: Busca global
Ctrl/Cmd + /: Abrir comandos
Esc: Fechar modais
Tab: Navegar entre elementos
Enter: Enviar mensagem (no chat)
```

## 8. Temas e Customização

### 8.1 Branding Customizável

Permitir que cada organização customize:
- Logo
- Cores primárias (accent colors)
- Favicon
- Nome da plataforma

### 8.2 Modo Claro/Escuro

Toggle no header do usuário para alternar entre temas.

## 9. Protótipo de Fluxo de Usuário

### 9.1 Primeiro Acesso (Onboarding)

```
1. Tela de boas-vindas
2. Criar primeiro agente (wizard guiado)
3. Configurar primeiro canal (WhatsApp ou Instagram)
4. Testar conversa com o agente
5. Dashboard com dados de exemplo
6. Tour interativo das funcionalidades
```

### 9.2 Fluxo de Atendimento

```
1. Notificação de nova conversa
2. Visualizar conversa na lista
3. Ler histórico e contexto
4. Decidir assumir ou deixar com IA
5. Se assumir: Responder com sugestões da IA
6. Atualizar informações do lead
7. Transferir de volta para IA ou fechar
```

## 10. Bibliotecas UI Recomendadas

**React/Next.js:**
- **Shadcn/ui**: Componentes base
- **Radix UI**: Primitivos acessíveis
- **Framer Motion**: Animações
- **Recharts**: Gráficos
- **React Hook Form**: Formulários
- **Zod**: Validação
- **Lucide Icons**: Ícones
- **Sonner**: Toast notifications
- **Vaul**: Drawers mobile
