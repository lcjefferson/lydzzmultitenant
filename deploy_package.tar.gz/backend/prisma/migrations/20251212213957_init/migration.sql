-- AlterTable
ALTER TABLE "leads" ALTER COLUMN "status" SET DEFAULT 'Lead Novo';
