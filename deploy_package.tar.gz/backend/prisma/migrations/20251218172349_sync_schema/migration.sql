-- AlterTable
ALTER TABLE "channels" ADD COLUMN     "provider" TEXT NOT NULL DEFAULT 'whatsapp-official';
